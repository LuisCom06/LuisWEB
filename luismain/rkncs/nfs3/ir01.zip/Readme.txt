Honda Integra Type-R `01 for Need for speed III

Title          : Honda Integra Type-R `01
Car            : Honda Integra Type-R `01 [based on Ford Falcon GT]
File           : ir01.zip
Version        : 1.0
Date           : SEP 2001

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Micha? "Michcio" Gadomski made Integra Type-R(-`00)'s Dash for my car.

Thanks.
___________________________________________________________

Have a fun !!