Acura NSX for Need for speed III

Title          : Acura NSX
Car            : Acura NSX `00 [based on Ford Falcon GT]
File           : nsx.zip
Version        : 2.0
Date           : DEC 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!