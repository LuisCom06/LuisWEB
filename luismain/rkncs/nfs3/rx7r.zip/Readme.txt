Mazda RX-7 Type-R Bathurst R for Need for speed III

Title          : Mazda RX-7 Type-R Bathurst R
Car            : Mazda RX-7 Type-R Bathurst R [based on Ford Falcon GT]
File           : rx7r.zip
Version        : 1.0
Date           : SEP 2001

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Luke Dieringer made `01 RX-7's Dash for my car.

Thanks.
___________________________________________________________

Have a fun !!