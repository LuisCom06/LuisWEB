Porsche 911 GT3 Cup for Need for speed III

Title          : Porsche 911 GT3 Cup
Car            : Porsche 911 GT3 Cup `02 [based on Porsche 911(NFS4)]
File           : pg3c.zip
Version        : 1.0
Date           : JUN 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.35 by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!