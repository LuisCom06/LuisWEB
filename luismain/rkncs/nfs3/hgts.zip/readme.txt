1. open your NFS3 Directory
2. go to (YOUR NFS3 DIRECTORY)/gamedata/carmodel
3. drag the folder of a car directly into carmodel directory
4. Enjoy!

for showcase
1. drag fedata folder into the fedata folder
2. enjoy!