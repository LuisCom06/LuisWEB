GM Goodwrench Service Chevrolet #3 for Need for speed III

Title          : GM Goodwrench Service Chevrolet #3
Car            : Chevrolet Monte Carlo(NASCAR) Car No.3 [based on MHRT Commodore(NFS4)]
File           : nas3.zip
Version        : 1.0
Date           : FEB 2001

Author         : Ryuji KAINOH
Email          : ryuji_k@pop13.odn.ne.jp
Homepage       : http://www1.odn.ne.jp/ryuji_k/nfs3.htm

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

Thanks.
___________________________________________________________

Have a fun !!


...Formula1(1987to2000) Carset for ICR2(IndycarRacing2)...
http://www1.odn.ne.jp/ryuji_k/