Toyota Corolla Levin AE86 for Need for speed III

Title          : Toyota Corolla Levin AE86
Car            : Toyota Corolla Levin (AE86) [based on Ford Falcon GT]
File           : ae86.zip
Version        : 2.5
Date           : DEC 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!