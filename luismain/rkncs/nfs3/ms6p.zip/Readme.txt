Mercedes S600 Pullman for Need for speed III

Title          : Mercedes S600 Pullman
Car            : Mercedes S600 Pullman [based on Ford Falcon GT]
File           : ms6p.zip
Version        : 1.0
Date           : NOV 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!