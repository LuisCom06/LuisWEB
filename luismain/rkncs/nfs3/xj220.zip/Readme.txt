Jaguar XJ220 for Need for speed III

Title          : Jaguar XJ220
Car            : Jaguar XJ220 [based on Lister Storm]
File           : xj220.zip
Version        : 1.0
Date           : MAY 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@pop13.odn.ne.jp
Homepage       : http://www1.odn.ne.jp/ryuji_k/nfs3.htm

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.7 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.35 by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!


...Formula1(1987to1998) Carset for ICR2(IndycarRacing2)...
http://www1.odn.ne.jp/ryuji_k/