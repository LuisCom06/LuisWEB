Lancia Delta WRC `92(Night SS) for Need for speed III

Car            : Lancia Delta HF Integrale WRC Version(Night SS) [based on Ford Falcon GT]
File           : delta3.zip
Version        : 1.0
Date           : AUB 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!