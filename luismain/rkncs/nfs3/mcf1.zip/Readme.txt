McLaren F1 for Need for speed III

Title          : McLaren F1
Car            : McLaren F1 [based on Ferrari McLaren F1 GTR(NFS4)]
File           : mcf1.zip
Version        : 2.0
Date           : JUN 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.35 by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!