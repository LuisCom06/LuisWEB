Aston Martin DB7 Vantage for Need for speed III

Title          : Aston Martin DB7 Vantage
Car            : Aston Martin DB7 Vantage [based on Aston Martin DB7(NFS4)]
File           : db7v.zip
Version        : 1.0
Date           : APR 2001

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!