Honda Civic Type-R for Need for speed III

Title          : Honda Civic Type-R
Car            : Honda Civic Type-R [based on Ford Falcon GT]
File           : civicr.zip
Version        : 2.0
Date           : NOV 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Micha? "Michcio" Gadomski made Civic Type-R's Dash for my car.

Thanks.
___________________________________________________________

Have a fun !!