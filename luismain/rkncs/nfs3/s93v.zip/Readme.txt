Saab 9-3 Viggen for Need for speed III

Title          : Saab 9-3 Viggen
Car            : Saab 9-3 Viggen [based on Ford Falcon GT]
File           : s93v.zip
Version        : 1.0
Date           : SEP 2001

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!