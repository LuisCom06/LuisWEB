Nissan Cima 450XV for Need for speed III

Title          : Nissan Cima 450XV
Car            : Nissan Cima 450XV [based on Ford Falcon GT]
File           : cm45.zip
Version        : 1.0
Date           : MAR 2001

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Nakanisism made R33GT-R's Dash(Modified by RK).presented by him!!

Thanks.
___________________________________________________________

Have a fun !!