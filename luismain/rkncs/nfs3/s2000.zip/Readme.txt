Honda S2000 for Need for speed III

Title          : Honda S2000
Car            : Honda S2000 [based on Jaguar XK8]
File           : s200.zip
Version        : 2.0
Date           : JUN 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.35 by Chris Barnard
               : PaintShop Pro 5J

* Micha� Gadomski made S2000's Dash for my car.

Thanks.
___________________________________________________________

Have a fun !!