Pursuit Impreza WRX Type-R STi Version VI for Need for speed III

Title          : Pursuit Impreza WRX STi Ver.VI
Car            : Subaru Impreza WRX Type-R STi Version VI [based on Ford Falcon GT]
File           : impcop.zip
Version        : 2.0
Date           : JUN 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!