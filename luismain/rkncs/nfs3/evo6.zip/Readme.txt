Mitsubishi Lancer Evolution VI for Need for speed III

Title          : Mitsubishi Lancer Evolution VI
Car            : Mitsubishi Lancer Evolution VI [based on Ford Falcon GT]
File           : evo6.zip
Version        : 5.0
Date           : AUG 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* YD(Yellow Devil) made Honda Beat's "CARP.TXT" for my car.

Thanks.
___________________________________________________________

Have a fun !!