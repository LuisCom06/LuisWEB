Lamborghini Diablo S-SV for Need for speed III

Car            : Lamborghini Diablo S-SV [based on Lamborghini Diablo SV]
File           : lssv.zip
Version        : 1.0
Date           : FEB 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!