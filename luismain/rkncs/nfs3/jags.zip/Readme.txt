Jaguar S-Type for Need for speed III

Title          : Jaguar S-Type
Car            : Jaguar S-Type [based on Ford Falcon GT]
File           : jags.zip
Version        : 2.0
Date           : DEC 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@pop13.odn.ne.jp
Homepage       : http://www1.odn.ne.jp/ryuji_k/nfs3.htm

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J


Thanks.
___________________________________________________________

Have a fun !!


...Formula1(1987to1998) Carset for ICR2(IndycarRacing2)...
http://www1.odn.ne.jp/ryuji_k/