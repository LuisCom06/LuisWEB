Nissan Maxima SE `00 for Need for speed III

Title          : Nissan Maxima SE `00
Car            : Nissan Maxima SE [based on Ford Falcon GT]
File           : maxima.zip
Version        : 1.0
Date           : MAR 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Micha? "Michcio" Gadomski made Maxima's Dash for my car.

Thanks.
___________________________________________________________

Have a fun !!