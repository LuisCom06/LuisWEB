Nissan 240SX for Need for speed III

Title          : Nissan 240SX S14
Car            : Nissan 240SX (S14) [based on Ford Falcon GT]
File           : s14.zip
Version        : 2.0
Date           : NOV 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Nakanisism made R33GT-R's Dash(Modified by RK).presented by him!!

Thanks.
___________________________________________________________

Have a fun !!