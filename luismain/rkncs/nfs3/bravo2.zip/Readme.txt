Fiat Bravo(for my Fiat Bravo ABARTH) for Need for speed III

Car            : Fiat Bravo [based on Ford Falcon GT]
File           : bravo2.zip
Version        : 1.0
Date           : MAY 1999

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.7 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.35 by Chris Barnard
               : PaintShop Pro 5J
Thanks.
___________________________________________________________

Have a fun !!