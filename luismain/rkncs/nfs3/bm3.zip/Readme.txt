BMW M3 E46 for Need for speed III

Title          : BMW M3 E46
Car            : BMW M3 [based on Ford Falcon GT]
File           : m3.zip
Version        : 1.0
Date           : JUN 2000

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : VIV Wizard v0.8 by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : PaintShop Pro 5J

* Micha� Gadomski made M3's Dash for my car.

Thanks.
___________________________________________________________

Have a fun !!