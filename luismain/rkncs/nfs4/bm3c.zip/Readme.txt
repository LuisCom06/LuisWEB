BMW M3 Convertible for Need for speed IV

Title          : BMW M3 Convertible
Car            : BMW M3 Convertible[E46] (SN:21)
File           : Bm3c.zip
Version        : 1.5 (Upgrade Feature : NO)
Date           : JAN 2002

Author         : Ryuji KAINOH
Email          : ryuji_k@iris.eonet.ne.jp
Homepage       : http://rkncs.totalnfs.net/

Used Editor(s) : Mrc(cartool.zip) by EA
               : NFS Wizard v0.5.0.79 by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 297) by Jesper Juul-Mortensen
               : VIV Wizard v0.8(build 299) by Jesper Juul-Mortensen
               : NFSIII Car CAD v1.4b by Chris Barnard
               : NFS Car CAD v1.5b by Chris Barnard
               : CAR3TO4 by J�Eg Billeter
               : NFS FCEConverter by Addict&Rocket
               : PaintShop Pro 5J

* CM_500 made M3's "CARP.TXT" for my car.

Thanks.
___________________________________________________________

Installation : Put the "car.viv" in "Data\Cars\Bm3c".
               and  the "Bm3c.qfs" in "Data\FeArt\VidWall".

Have a fun !!